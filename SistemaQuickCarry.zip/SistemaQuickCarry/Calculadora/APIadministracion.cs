﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;

namespace SistemaQuickCarry
{
    class APIadministracion
    {
        public class Empleado
        {
            public int IDEmpleado { get; set; }
            public string PrimerNombre { get; set; }
            public string SegundoNombre { get; set; }
            public string PrimerApellido { get; set; }
            public string SegundoApellido { get; set; }
            public string Usuario { get; set; }
            public string Rol { get; set; }
            public int ci { get; set; }
        }

        public static string BuscarEmpleado(string ci)
        {
            string sql;
            ADODB.Recordset rs;
            object filasAfectadas;
            string resultado = "1";
            Empleado em = JsonSerializer.Deserialize<Empleado>(ci);

            if (Program.cn.State == 0)
            {
                resultado = "1"; // conexión cerrada
            }
            else
            {
                sql = $"SELECT Empleado.Usuario, Empleado.IDEmpleado, Almacenero.EsAdmin, Empleado.PrimerApellido, Empleado.SegundoApellido, " +
                      $"Empleado.PrimerNombre, Empleado.SegundoNombre, " +
                      $"CASE " +
                          $"WHEN ConductorCamion.IDEmpleado IS NOT NULL THEN 'Chofer' " +
                          $"WHEN ConductorCamioneta.IDEmpleado IS NOT NULL THEN 'Chofer' " +
                          $"WHEN Almacenero.EsAdmin = 1 THEN 'Administrador' " +
                          $"ELSE 'Almacenero'" +
                      $"END AS Rol " +
                      $"FROM Empleado " +
                      $"LEFT JOIN Almacenero ON Empleado.IDEmpleado = Almacenero.IDEmpleado " +
                      $"LEFT JOIN ConductorCamion ON Empleado.IDEmpleado = ConductorCamion.IDEmpleado " +
                      $"LEFT JOIN ConductorCamioneta ON Empleado.IDEmpleado = ConductorCamioneta.IDEmpleado " +
                      $"WHERE Empleado.NroDocumento = {em.ci}";

                try
                {
                    rs = Program.cn.Execute(sql, out filasAfectadas);

                    if (rs.RecordCount > 0)
                    {
                        em.IDEmpleado = Convert.ToInt32(rs.Fields["IDEmpleado"].Value);
                        em.PrimerNombre = Convert.ToString(rs.Fields["PrimerNombre"].Value);
                        em.SegundoNombre = Convert.ToString(rs.Fields["SegundoNombre"].Value);
                        em.PrimerApellido = Convert.ToString(rs.Fields["PrimerApellido"].Value);
                        em.SegundoApellido = Convert.ToString(rs.Fields["SegundoApellido"].Value);
                        em.Usuario = Convert.ToString(rs.Fields["Usuario"].Value);
                        em.Rol = Convert.ToString(rs.Fields["Rol"].Value);
                        

                        resultado = JsonSerializer.Serialize(em); // encontrado
                    }
                    else
                    {
                        resultado = "3"; // no encontrado
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    resultado = "2"; // error al buscar usuarios
                }
            }

            return resultado;
        }
    }
}
