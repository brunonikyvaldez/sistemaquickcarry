﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaQuickCarry
{
    public partial class Inventario : Form
    {
        public Inventario()
        {
            InitializeComponent();
        }

        private void Inventario_Load(object sender, EventArgs e)
        {
            txtAnioPerecedero.Enabled = false;
            txtMesPerecedero.Enabled = false;
            txtDiaPerecedero.Enabled = false;
        }

        private void cbxTipoPaquete_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtAnioPerecedero.Enabled = cbxTipoPaquete.SelectedItem.ToString().Equals("Perecedero") ? true : false;
            txtMesPerecedero.Enabled= cbxTipoPaquete.SelectedItem.ToString().Equals("Perecedero") ? true : false;
            txtDiaPerecedero.Enabled= cbxTipoPaquete.SelectedItem.ToString().Equals("Perecedero") ? true : false;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            int anio = 0;
            int mes = 0;
            int dia = 0;
            int ci = Convert.ToInt32(txtCiDestinatario.Text);
            if (txtAnioPerecedero.Enabled == true)
            {
                try
                {
                    anio = Convert.ToInt16(txtAnioPerecedero.Text);
                    mes = Convert.ToInt16(txtMesPerecedero.Text);
                    dia = Convert.ToInt16(txtDiaPerecedero.Text);
                    ci = Convert.ToInt32(txtCiDestinatario.Text);
                }
                catch
                {
                    MessageBox.Show("Asegurate de que las fechas y cedula sean numericas");
                    return;
                }
                if (Paquete.ValidarFecha(anio, mes, dia) == false)
                {
                    MessageBox.Show("Por favor ingrese una fecha valida");
                    return;
                }
            }
            Paquete al = new Paquete

            {
                TipoPaquete = cbxTipoPaquete.SelectedItem.ToString() == "Perecedero"
                    ? anio + "-" + mes + "-" + dia
                    : cbxTipoPaquete.SelectedItem.ToString(),
                ciDestinatario = ci,
                DestinoPaquete = txtDireccionDestino.Text,
                ciudadDestinoPaquete = cbxCiudadDestino.SelectedItem.ToString(),
                pesoPaquete = Convert.ToInt32(txtPesoPaquete.Text),
            };
            switch (al.GuardarPaquete())
            {
                case 0:
                    MessageBox.Show("Operacion Realizada con exito");
                    break;
                case 1:
                    MessageBox.Show("Por favor reinicie la aplicacion");
                    break;
                case 2:
                    MessageBox.Show("Problema al intentar crear paquete");
                    break;
            }

        }
    }
}
