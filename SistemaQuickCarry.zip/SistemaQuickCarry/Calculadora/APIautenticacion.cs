﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;

namespace SistemaQuickCarry
{
    class APIautenticacion
    {
        public static string ValidoRol(string usuario)
        {

            Program.cn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;
            string resultado = "ClosedCn";
            UsuPass up = JsonSerializer.Deserialize<UsuPass>(usuario); // Asumo que UsuPass contiene la estructura necesaria
            Console.Write(up.usuario);
            string sql;
            ADODB.Recordset rs = new ADODB.Recordset();
            object filasAfectadas;
            Console.WriteLine(Program.cn.State);
            if (Program.cn.State == 0)
            {
                Console.WriteLine("error1");
                return resultado;
            }
            else
            {
                // Sentencia SQL para obtener el ID del empleado, su rol y su contraseña
                sql = $"SELECT Empleado.IDEmpleado, Almacenero.EsAdmin, " +
                      $"CASE " +
                          $"WHEN ConductorCamion.IDEmpleado IS NOT NULL THEN 'Chofer' " +
                          $"WHEN ConductorCamioneta.IDEmpleado IS NOT NULL THEN 'Chofer' " +
                          $"ELSE 'Almacenero' " +
                      $"END AS Rol " +
                      $"FROM Empleado " +
                      $"LEFT JOIN Almacenero ON Empleado.IDEmpleado = Almacenero.IDEmpleado " +
                      $"LEFT JOIN ConductorCamion ON Empleado.IDEmpleado = ConductorCamion.IDEmpleado " +
                      $"LEFT JOIN ConductorCamioneta ON Empleado.IDEmpleado = ConductorCamioneta.IDEmpleado " +
                      $"WHERE Empleado.Usuario ='{up.usuario}'";

                try
                {
                    rs = Program.cn.Execute(sql, out filasAfectadas);
                }
                catch (Exception ex)
                {
                    Console.Write(ex);
                    rs = null;
                    Program.cn.Close();
                    return "RolError";
                }
               

                if (rs.RecordCount > 0)
                {
                    bool? esAdmin;
                    try
                    {
                        esAdmin = Convert.ToBoolean(rs.Fields[1].Value);
                    }catch{
                        esAdmin = null;
                    }

                    string rol = rs.Fields[2].Value.ToString();
                    

                    UsuRol ur = new UsuRol();
                    ur.admin = esAdmin;
                    ur.usuario = usuario;
                    ur.rol = rol;
                    resultado = JsonSerializer.Serialize(ur);
                    Program.idEmpleado = Convert.ToInt32(rs.Fields[1].Value);
                }
            }
            Console.WriteLine(rs.RecordCount);
            Console.WriteLine("error2");
            rs.Close(); // Cerrar el recordset
            return resultado;
            
        }
        public static byte login(string usupass)
        {
            UsuPass up;
            up = JsonSerializer.Deserialize<UsuPass>(usupass);

            try
            {
                // Verifica si la conexión ya está abierta antes de intentar abrirla
                if (Program.cn.State == 0)
                {
                    Program.cn.Open("MioDBC", up.usuario, up.contrasenia);
                    
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);

                return 1;
            }

            return 0;
        }


        public class UsuPass
        {
            public string usuario { set; get; }
            public string contrasenia { set; get; }
        }

        public class UsuRol
        {
            public string usuario { set; get; }
            public string rol { set; get; }

            public bool? admin { set; get; }
        }
    }
}
