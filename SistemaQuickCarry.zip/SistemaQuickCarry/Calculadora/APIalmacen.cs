﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;


namespace SistemaQuickCarry
{
    class APIalmacen
    {
        public class Paquete
        {
            public int idPaquete { set; get; }
            public string DestinoPaquete { set; get; }
            public string ciudadDestinoPaquete { set; get; }
            public string tipoPaquete { set; get; }
            public int ciDestinatario { set; get; }
            public string estadoPaquete { set; get; }
            public int pesoPaquete { set; get; }
        }

        public class PaqueLote {
            public int _GuiaMadre { set; get; }
            public int _CodigoBarras { set; get; }

        }

        public class LotTrayeLoc {
            public string _direccionLocal { set; get; }
            public string _nombreTrayecto { set; get; }

            public int _GuiaMadre { set; get; }
        }
        public static string BuscarCiudades()
        {
            object filasAfectadas;

            ADODB.Connection conexion = Program.cn;
            ADODB.Recordset rs;
            List<string> ciudades = new List<string>();
            List<string> direcciones = new List<string>();
            string ciudadesSer = "NotFound";

            if (conexion.State != 0)
            {
                try
                {
                    // Busca todos los locales que tienen asignado algún trayecto
                    string sql = "SELECT Locales.IdLocal, CiudadLocal " +
                                 "FROM Locales " +
                                 "INNER JOIN Sectores ON Locales.IdLocal = Sectores.IdLocal " +
                                 "INNER JOIN Trayectos ON Sectores.IdTrayecto = Trayectos.IdTrayecto " +
                                 "GROUP BY Locales.IdLocal, Locales.CiudadLocal";

                    rs = conexion.Execute(sql, out filasAfectadas);
                    // Rellena el la lista ciudades con las ciudades de los locales encontrados

                    while (rs.EOF == false)
                    {
                        ciudades.Add(rs.Fields["CiudadLocal"].Value.ToString());
                        
                        rs.MoveNext();
                    }
                    ciudadesSer = JsonSerializer.Serialize(ciudades);
                    rs.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
            return ciudadesSer;
        }

        public static string BuscarDirecciones(string ciudad)
        {
            object filasAfectadas;
            ADODB.Connection conexion = Program.cn;
            ADODB.Recordset rs;
            List<string> direcciones = new List<string>();
            string direccionesSer = "NotFound";

            if (conexion.State != 0)
            {
                try
                {
                    // Busca las direcciones de los locales en la ciudad especificada
                    string sql = $"SELECT Locales.DireccionLocal " +
                                 $"FROM Locales " +
                                 $"INNER JOIN Sectores ON Locales.IdLocal = Sectores.IdLocal " +
                                 $"INNER JOIN Trayectos ON Sectores.IdTrayecto = Trayectos.IdTrayecto " +
                                 $"WHERE Locales.CiudadLocal = '{ciudad}' " +
                                 $"GROUP BY Locales.DireccionLocal";

                    rs = conexion.Execute(sql, out filasAfectadas);

                    // Rellena la lista direcciones con las direcciones de los locales encontrados
                    while (rs.EOF == false)
                    {
                        direcciones.Add(rs.Fields["DireccionLocal"].Value.ToString());
                        rs.MoveNext();
                    }

                    direccionesSer = JsonSerializer.Serialize(direcciones);
                    rs.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
            return direccionesSer;
        }


        public static string BuscarTrayecto(string direccionLocal)
        {
            object filasAfectadas;
            ADODB.Connection conexion = Program.cn;
            ADODB.Recordset rs;
            List<string> trayectos = new List<string>();
            string trayectosSer = "NotFound";

            if (conexion.State != 0)
            {
                try
                {
                    // Busca los trayectos que pasan por el local con la dirección especificada
                    string sql = $"SELECT Trayectos.NombreTrayecto " +
                                 $"FROM Locales " +
                                 $"INNER JOIN Sectores ON Locales.IdLocal = Sectores.IdLocal " +
                                 $"INNER JOIN Trayectos ON Sectores.IdTrayecto = Trayectos.IdTrayecto " +
                                 $"WHERE Locales.DireccionLocal = '{direccionLocal}' " +
                                 $"GROUP BY Trayectos.NombreTrayecto";

                    rs = conexion.Execute(sql, out filasAfectadas);

                    // Rellena la lista trayectos con los nombres de los trayectos encontrados
                    while (rs.EOF == false)
                    {
                        trayectos.Add(rs.Fields["NombreTrayecto"].Value.ToString());
                        rs.MoveNext();
                    }

                    trayectosSer = JsonSerializer.Serialize(trayectos);
                    rs.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
            return trayectosSer;
        }


        public static string BuscarPaquete(string PaqueteSer, string CiudadDestinoLote)
        {
            string sql;
            ADODB.Connection conexion = Program.cn;
            ADODB.Recordset rs;
            object filasAfectadas;
            string resultadoSerializado = null;

            SistemaQuickCarry.Paquete pa = JsonSerializer.Deserialize<SistemaQuickCarry.Paquete>(PaqueteSer);

            if (conexion.State != 0)
            {
                sql = "SELECT Cedula,EstadoP, TipoPaquete, DireccionDestino, CiudadDestino " +
                     "FROM Paquete " +
                     $"WHERE CodigoDeBarras = {pa.IdPaquete}";

                try
                {
                    rs = conexion.Execute(sql, out filasAfectadas);

                    if (rs.RecordCount > 0)
                    {
                        // Se encontraron resultados, puedes procesarlos aquí
                        SistemaQuickCarry.Paquete resultadoPaquete = new SistemaQuickCarry.Paquete
                        {
                            IdPaquete = pa.IdPaquete,
                            EstadoPaquete = Convert.ToString(rs.Fields["EstadoP"].Value),
                            ciDestinatario = Convert.ToInt32(rs.Fields["Cedula"].Value),
                            TipoPaquete = Convert.ToString(rs.Fields["TipoPaquete"].Value),
                            DestinoPaquete = Convert.ToString(rs.Fields["DireccionDestino"].Value),
                            ciudadDestinoPaquete = Convert.ToString(rs.Fields["CiudadDestino"].Value)
                        };
                        Console.WriteLine(resultadoPaquete.TipoPaquete);

                        // Verifica si la ciudad de destino coincide con la ciudad del lote
                        if (resultadoPaquete.ciudadDestinoPaquete == CiudadDestinoLote)
                        {
                            // Serializa el paquete y lo asigna a resultadoSerializado
                            resultadoSerializado = JsonSerializer.Serialize(resultadoPaquete);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    // Manejo de errores aquí
                }
            }
            else
            {
                // Conexión cerrada
                // Manejo de errores aquí
            }

            return resultadoSerializado;
        }

        public static byte InsertarCorresponde(string infoser)
        {
            string sql;
            LotTrayeLoc info = JsonSerializer.Deserialize<LotTrayeLoc>(infoser);
            object filasAfectadas;
            byte resultado = 0;
            ADODB.Connection conexion = Program.cn;

            if (conexion.State != 0)
            {
                try
                {
                    // Obtener el ID del local por su dirección
                    int idLocal = ObtenerIdLocalPorDireccion(info._direccionLocal);

                    // Obtener el ID del trayecto por su nombre
                    int idTrayecto = ObtenerIdTrayectoPorNombre(info._nombreTrayecto);

                    // Insertar en la tabla Corresponde
                    sql = $"INSERT INTO Corresponde (GuiaMadre, IdLocal, IdTrayecto) " +
                          $"VALUES ({info._GuiaMadre}, {idLocal}, {idTrayecto})";

                    try
                    {
                        conexion.BeginTrans(); // Iniciar una transacción

                        conexion.Execute(sql, out filasAfectadas);

                        conexion.CommitTrans(); // Confirmar la transacción
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                        conexion.RollbackTrans(); // Revertir la transacción en caso de error
                        resultado = 2; // error al insertar en la tabla Corresponde
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
            else
            {
                resultado = 1; // conexión cerrada
            }

            return resultado;
        }

        // Función para obtener el ID del local por su dirección
        private static int ObtenerIdLocalPorDireccion(string direccionLocal)
        {
            int idLocal = -1;
            string sql = $"SELECT IdLocal FROM Locales WHERE DireccionLocal = '{direccionLocal}'";
            ADODB.Connection conexion = Program.cn;
            object filasAfectadas;

            if (conexion.State != 0)
            {
                try
                {
                    ADODB.Recordset rs = new ADODB.Recordset();
                    rs = conexion.Execute(sql, out filasAfectadas);

                    if (rs.RecordCount > 0)
                    {
                        idLocal = Convert.ToInt32(rs.Fields["IdLocal"].Value);
                    }

                    rs.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    // Manejar el error según tus necesidades
                }
            }

            return idLocal;
        }

        // Función para obtener el ID del trayecto por su nombre
        private static int ObtenerIdTrayectoPorNombre(string nombreTrayecto)
        {
            int idTrayecto = -1;
            string sql = $"SELECT IdTrayecto FROM Trayectos WHERE NombreTrayecto = '{nombreTrayecto}'";
            ADODB.Connection conexion = Program.cn;
            object filasAfectadas;

            if (conexion.State != 0)
            {
                try
                {
                    ADODB.Recordset rs = new ADODB.Recordset();
                    rs = conexion.Execute(sql, out filasAfectadas);

                    if (rs.RecordCount > 0)
                    {
                        idTrayecto = Convert.ToInt32(rs.Fields["IdTrayecto"].Value);
                    }

                    rs.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    // Manejar el error según tus necesidades
                }
            }

            return idTrayecto;
        }

        public static int GuardarLote()
        {
            string sql;
            object filasAfectadas;
            int guiaMadre = -1; // Valor por defecto en caso de error
            ADODB.Connection conexion = Program.cn;
            ADODB.Recordset rs = new ADODB.Recordset();

            if (conexion.State != 0)
            {

                // Obtener la fecha y hora actuales
                DateTime fechaActual = DateTime.Now;

                sql = $"INSERT INTO Lote (FechaIngresoL) " +
                        $"VALUES ('{fechaActual.Year}-{fechaActual.Month}-{fechaActual.Day}')";

                conexion.BeginTrans(); // Iniciar una transacción

                conexion.Execute(sql, out filasAfectadas);

                conexion.CommitTrans(); // Confirmar la transacción

                sql= "SELECT GuiaMadre FROM Lote ORDER BY GuiaMadre DESC LIMIT 1";

                rs = conexion.Execute(sql,out filasAfectadas);

                if (rs.RecordCount > 0)
                {
                    guiaMadre = Convert.ToInt32(rs.Fields["GuiaMadre"].Value);
                }

                rs.Close();
            }


            return guiaMadre;
        }

        public static int AgregarPaqueteALote(string paquelote)
        {
            string sqlInsertContiene;
            string sqlUpdatePaquete;
            object filasAfectadas;
            int resultado = 0;
            PaqueLote pl = JsonSerializer.Deserialize<PaqueLote>(paquelote);
            ADODB.Connection conexion = Program.cn;

            if (conexion.State != 0)
            {
                try
                {
                    // Insertar en la tabla Contiene
                    sqlInsertContiene = $"INSERT INTO Contiene (GuiaMadre, CodigoDeBarras) " +
                                        $"VALUES ({pl._GuiaMadre}, {pl._CodigoBarras})";

                    // Actualizar el estado del paquete a 'En Lote'
                    sqlUpdatePaquete = $"UPDATE Paquete SET EstadoP = 'En Lote' WHERE CodigoDeBarras = {pl._CodigoBarras}";

                    try
                    {
                        conexion.BeginTrans(); // Iniciar una transacción

                        // Ejecutar la inserción en Contiene
                        conexion.Execute(sqlInsertContiene, out filasAfectadas);

                        // Ejecutar la actualización del estado del paquete
                        conexion.Execute(sqlUpdatePaquete, out filasAfectadas);

                        conexion.CommitTrans(); // Confirmar la transacción
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                        conexion.RollbackTrans(); // Revertir la transacción en caso de error
                        resultado = 2; // error al insertar en la tabla Contiene o al actualizar el estado del paquete
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
            else
            {
                resultado = 1; // conexión cerrada
            }

            return resultado;
        }




        public static byte GuardarPaquete(string PaqueteSerializado)
        {
            string sql;
            object filasAfectadas;
            byte resultado = 0;
            Paquete ps;
            ps = JsonSerializer.Deserialize<Paquete>(PaqueteSerializado);
            ADODB.Connection conexion = Program.cn;

            if (conexion.State != 0)
            {
                try
                {
                    // Obtener la fecha y hora actuales
                    DateTime fechaActual = DateTime.Now;

                    sql = $"INSERT INTO Paquete (TipoPaquete, Cedula, EstadoP, DireccionDestino, CiudadDestino, FechaIngresoP, PesoP) " +
                          $"VALUES ('{ps.tipoPaquete}', {ps.ciDestinatario}, '{ps.estadoPaquete}', '{ps.DestinoPaquete}', '{ps.ciudadDestinoPaquete}', " +
                          $"'{fechaActual.Year+"-"+fechaActual.Month+"-"+fechaActual.Day}', {ps.pesoPaquete})";

                    try
                    {
                        conexion.BeginTrans(); // Iniciar una transacción

                        conexion.Execute(sql, out filasAfectadas);

                        conexion.CommitTrans(); // Confirmar la transacción
                    }
                    catch(Exception ex)
                    {
                        Console.WriteLine(ex);
                        conexion.RollbackTrans(); // Revertir la transacción en caso de error
                        resultado = 2; // error al insertar en la tabla
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
            else
            {
                resultado = 1; // conexión cerrada
            }

            return resultado;
        }
    }
}
