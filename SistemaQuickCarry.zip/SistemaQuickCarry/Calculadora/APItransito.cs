﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;

namespace SistemaQuickCarry
{
    class APItransito
    {
        public class Planilla {
            public List<int> idLote { set; get; }
            public List<string> Locales { set; get; }
            public List<string> HoraLLegadaEstimada { set; get; }
            public string HoraSalida { set; get; }
            public List<string> HoraLLegada { set; get; }

        }
        public class camionChofer {

            public string Matricula {set;get;}
            public int idChofer { set; get; }

        }

        public static string ObtenerDatosPlanilla()
        {
            Planilla planilla = new Planilla();


            camionChofer cacho = new camionChofer
            {
                Matricula = ObtenerMatriculaCamion(Program.idEmpleado),
                idChofer = Program.idEmpleado
            };

          

            return JsonSerializer.Serialize( planilla);
        }
        public static string ObtenerMatriculaCamion(int idConductorCamion)
        {
            string sql = $"SELECT cc.Matricula " +
                         $"FROM ConduceCamion cc " +
                         $"JOIN ConductorCamion c ON cc.IDEmpleado = c.IDEmpleado " +
                         $"WHERE c.IDEmpleado = {idConductorCamion}";

            try
            {
                ADODB.Recordset rs = Program.cn.Execute(sql, out object filasAfectadas);

                if (rs.RecordCount > 0)
                {
                    string matricula = Convert.ToString(rs.Fields["Matricula"].Value);
                    return matricula;
                }
                else
                {
                    return "No se encontró ninguna matrícula para el conductor de camión especificado.";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return "Error al obtener la matrícula del camión.";
            }
        }


    }
}
