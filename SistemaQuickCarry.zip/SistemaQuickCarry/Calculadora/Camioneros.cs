﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaQuickCarry
{
    public partial class Camioneros : Form
    {
        private int n = 0;
        public Camioneros()
        {
            InitializeComponent();
        }

        private void btnSalidaCamion_Click(object sender, EventArgs e)
        {

        }

        private void Camioneros_Load(object sender, EventArgs e)
        {
            
        }

        private void dgvCamiones_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            n = e.RowIndex;
            Console.WriteLine(n);
        }
    }
}
