﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using ADODB;

namespace SistemaQuickCarry
{

    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        public static Principal frmPrincipal;
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(frmPrincipal = new Principal());
            
        }
        

        public static ADODB.Connection cn = new ADODB.Connection();
        private static Recordset nothing;
        public static int idEmpleado;
        
        public static void DoyPermisos(bool esAdmin, string rol)
        {
            frmPrincipal.menuAplicaciones.Enabled = false;
            frmPrincipal.menuAdmin.Enabled = false;
            frmPrincipal.menuChofer.Enabled = false;
            frmPrincipal.menuAlmacen.Enabled = false;

          
            if (esAdmin)
            {
                frmPrincipal.menuAplicaciones.Enabled = true;
                frmPrincipal.menuAdmin.Enabled = true;
                frmPrincipal.menuLogin.Enabled = false;
            }
            
            // No es administrador, determina el rol y habilita los menús correspondientes
            switch (rol)
            {
                case "Chofer":
                    frmPrincipal.menuAplicaciones.Enabled = true;
                    frmPrincipal.menuChofer.Enabled = true;
                    frmPrincipal.menuLogin.Enabled = false;
                    break;
                case "Almacenero":
                    frmPrincipal.menuAplicaciones.Enabled = true;
                    frmPrincipal.menuAlmacen.Enabled = true;
                    frmPrincipal.menuLogin.Enabled = false;
                    break;
                default:
                    // Puedes manejar otros roles u opciones aquí si es necesario
                    break;
            }
        }
    }
}
    

