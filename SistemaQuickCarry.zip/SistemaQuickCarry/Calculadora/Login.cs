﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json;

namespace SistemaQuickCarry
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            string upSerializado;
            string resultado;
            byte loginStatus; 
            APIautenticacion.UsuRol ur = new APIautenticacion.UsuRol();
            APIautenticacion.UsuPass up = new APIautenticacion.UsuPass();
            bool admin = true;
            up.usuario = txtUsuario.Text;
            up.contrasenia = txtContrasenia.Text;
            upSerializado = JsonSerializer.Serialize(up);
            loginStatus = APIautenticacion.login(upSerializado);
            if (loginStatus == 1)
            {
                MessageBox.Show("Usuario o Contraseña incorrectos");
                return;
            }

            resultado = APIautenticacion.ValidoRol(upSerializado);

            if (resultado == "RolError")
            {
                MessageBox.Show("Error con la conexion, vuelva a iniciar sesion");
                return;
            }
            if (resultado == "ClosedCn")
            {
                MessageBox.Show("Checkee su conexion e intente de nuevo");
                return;
            }
            ur = JsonSerializer.Deserialize<APIautenticacion.UsuRol>(resultado);
            if (ur.admin == null | ur.admin == false)
            {
                admin= false;
            }
            Program.DoyPermisos(admin,ur.rol);                          
            this.Close();
        }
        

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtUsuario_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
