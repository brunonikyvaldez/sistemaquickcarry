﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;

namespace SistemaQuickCarry
{
    class Paquete
    {
        protected byte _idPaquete;
        protected string _DestinoPaquete;
        protected string _ciudadDestinoPaquete;
        protected string _tipoPaquete;
        protected int _ciDestinatario;
        protected string _estadoPaquete;
        protected int _pesoPaquete;

        public int pesoPaquete
        {
            set { _pesoPaquete = value; }
            get { return _pesoPaquete; }
        }
        public string ciudadDestinoPaquete
        {
            set { _ciudadDestinoPaquete = value; }
            get { return _ciudadDestinoPaquete; }
        }
        public byte IdPaquete
        {
            set { _idPaquete = value; }
            get { return _idPaquete; }
        }
        public string DestinoPaquete
        {
            set { _DestinoPaquete = value; }
            get { return _DestinoPaquete; }
        }

        public string TipoPaquete
        {
            set { _tipoPaquete = value; }
            get { return _tipoPaquete; }
        }

        public int ciDestinatario
        {
            set { _ciDestinatario = value; }
            get { return _ciDestinatario; }
        }

        public string EstadoPaquete
        {
            set { _estadoPaquete = value; }
            get { return _estadoPaquete; }
        }
        public Paquete()
        {
            _ciDestinatario = 12345678;
            _DestinoPaquete = null;
            _estadoPaquete = "En Central";
            _idPaquete = 0;
            _tipoPaquete = null;
        }

        public byte GuardarPaquete()
        {
            byte resultado = 0;
            APIalmacen.Paquete paquete = new APIalmacen.Paquete
            {
                ciDestinatario = _ciDestinatario,
                ciudadDestinoPaquete = _ciudadDestinoPaquete,
                DestinoPaquete = _DestinoPaquete,
                estadoPaquete = _estadoPaquete,
                pesoPaquete = _pesoPaquete,
                tipoPaquete = _tipoPaquete
            };

            string paqueteSerializado = JsonSerializer.Serialize(paquete);
            resultado = APIalmacen.GuardarPaquete(paqueteSerializado);

            return resultado;
        }

        public static bool ValidarFecha(int anio, int mes, int dia)
        {
            // Verifica si los valores son enteros
            if (anio < 1 || anio > 9999)
            {
                // No es un entero válido
                return false;
            }

            if (mes < 1 || mes > 12)
            {
                // No es un entero válido
                return false;
            }

            // Verifica el caso de febrero
            if (mes == 2)
            {
                // Es febrero
                if (anio % 4 == 0 && anio % 100 != 0 || anio % 400 == 0)
                {
                    // Es un año bisiesto
                    if (dia < 1 || dia > 29)
                    {
                        // No es un valor válido
                        return false;
                    }
                }
                else
                {
                    // No es un año bisiesto
                    if (dia < 1 || dia > 28)
                    {
                        // No es un valor válido
                        return false;
                    }
                }
            }
            else
            {
                // No es febrero
                if (dia < 1 || dia > 31)
                {
                    // No es un valor válido
                    return false;
                }
            }

            // Obtiene la fecha actual
            DateTime fechaActual = DateTime.Now;

            // Verifica si la fecha es menor que la fecha actual
            if (fechaActual.Year > anio ||
                fechaActual.Year == anio && fechaActual.Month > mes ||
                fechaActual.Year == anio && fechaActual.Month == mes && fechaActual.Day > dia)
            {
                // Es una fecha menor que la actual
                return false;
            }

            // Los valores son válidos
            return true;
        }
    }
}
