﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json;

namespace SistemaQuickCarry
{
    public partial class Administrador : Form
    {
        public Administrador()
        {
            InitializeComponent();
        }

        private void Clientes_Load(object sender, EventArgs e)
        {
            gbDatos.Visible = false;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            APIadministracion.Empleado c = new APIadministracion.Empleado();
            Int32 ci;
            DialogResult respuesta;
            if (!Int32.TryParse(txtCi.Text, out ci))
            {
                MessageBox.Show("La CI debe ser solo numérica");
            }
            else
            {
                c.ci = ci;
                string ciSer = JsonSerializer.Serialize(c);
                string emSer = APIadministracion.BuscarEmpleado(ciSer);
                switch (emSer)
                {
                    case "1": //Conexión cerrada
                        MessageBox.Show("Debe loguearse manualmente");
                        break;
                    case "2": //Error al buscar cliente
                        MessageBox.Show("Error al buscar datos");
                        break;
                    case "3": //No encontré
                        respuesta = MessageBox.Show("No se encontró ese usuario");
                        break;
                    default: //Encontró
                        APIadministracion.Empleado cEncontrado = JsonSerializer.Deserialize<APIadministracion.Empleado>(emSer);
                        gbBuscar.Enabled = false;
                        gbDatos.Visible = true;
                        btnEliminar.Enabled = true;
                        lblNombrePersona.Text = cEncontrado.PrimerNombre + " " + cEncontrado.SegundoNombre + " " + cEncontrado.PrimerApellido + " " + cEncontrado.SegundoApellido;
                        lblIdUsuario.Text = Convert.ToString(cEncontrado.IDEmpleado);
                        lblRolUsuario.Text = cEncontrado.Rol;
                        break;
                }//switch
            }//else
            c = null; //Destruyo el objeto de la clase cliente
        }//btnB

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            Int32 ci;
            DialogResult respuesta;
            Empleados c = new Empleados();
            if(!Int32.TryParse(txtCi.Text, out ci))
            {
                MessageBox.Show("CI debe ser numérica");
            }
            else
            {
                c.conexion = Program.cn;
                c.idUsuario=Convert.ToByte(lblIdUsuario.Text);
                respuesta = MessageBox.Show("¿Está seguro?", "Eliminar Usuario", MessageBoxButtons.YesNo);
                if (respuesta == DialogResult.Yes)
                {
                    switch (c.Eliminar())
                    {
                        case 0: gbBuscar.Enabled = true;
                            gbDatos.Visible = false;
                            break;
                        case 1: MessageBox.Show("Debe loguearse nuevamente");
                            break;
                        default:MessageBox.Show("Hubo errores al efectuar la operación, reintente.");
                            break;
                    }
                }
                c = null;
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Empleados c = new Empleados();
            Int32 ci;
            c.conexion = Program.cn;
            if (!Int32.TryParse(txtGuardarCi.Text, out ci))
            {
                MessageBox.Show("La CI debe ser solo numérica");
            }else if (txtContrasenia.Text != txtConfContrasenia.Text)
            {
                MessageBox.Show("Las contraseñas no son iguales");
            }
            else
            {
                c.primerNombre = txtGuardarNombre1.Text;
                c.segundoNombre = txtGuardarNombre2.Text;
                c.primerApellido = txtGuardarApellido1.Text;
                c.segundoApellido = txtGuardarApellido2.Text;
                c.ci = Convert.ToInt32(txtGuardarCi.Text);
                c.contrasenia = txtConfContrasenia.Text;
                c.rol = cbxRol.SelectedItem.ToString();
                c.usuario = txtUsuario.Text;
                switch (c.Guardar())
                {
                    case 0:
                        MessageBox.Show("Operacion Realizada con exito");
                        break;
                    case 1:
                        MessageBox.Show("Debe loguearse manualmente");
                        break;
                    case 2:
                        MessageBox.Show("Problema al intentar crear usuario");
                        break;
                    case 3:
                        MessageBox.Show("Error al tratar de dar permisos");
                        break;
                    case 4:
                        MessageBox.Show("Error con la id del usuario generada");
                        break;
                }
            }

        }

        private void txtCi_TextChanged(object sender, EventArgs e)
        {

        }

        private void cbxRol_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void gbGuardarDatos_Enter(object sender, EventArgs e)
        {

        }

        private void lblGuardarNombre1_Click(object sender, EventArgs e)
        {

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            gbBuscar.Enabled = true;
            gbDatos.Visible = false;
            btnEliminar.Enabled = false;
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
