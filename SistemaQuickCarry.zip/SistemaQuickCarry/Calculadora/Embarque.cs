﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json;

namespace SistemaQuickCarry
{
    public partial class Embarque : Form
    {
        private int n=0;
        public Embarque()
        {
            InitializeComponent();
        }

        private void Embarque_Load(object sender, EventArgs e)
        {
            gbxIds.Enabled = false;
            gbxIds.Visible = false;
            cbxTrayecto.Enabled = false;
            cbxDireccion.Enabled = false;
           
            string CiudadesSer = APIalmacen.BuscarCiudades();
            if (CiudadesSer == "NotFound")
            {
                MessageBox.Show("Ingrese Nuevamente al Sistema");
                Program.cn.Close();
                Close();
                return;
            }
            List<string> Ciudades = JsonSerializer.Deserialize<List<string>>(CiudadesSer);
            foreach (string ciudad in Ciudades)
            {
                cbxHasta.Items.Add(ciudad);
            }
        }



        private void btnConfirmarDestinos_Click(object sender, EventArgs e)
        {
            if (cbxHasta.SelectedItem != null)
            {
                Console.WriteLine(cbxHasta.SelectedItem.ToString());

                cbxHasta.Enabled = false;
                gbxIds.Enabled = true;
                gbxIds.Visible = true;
                btnConfirmarDestinos.Enabled = false;
            }
            else
            {
                MessageBox.Show("Elige una Ciudad para crear el lote");
            } 
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            cbxHasta.Enabled = true;
            gbxIds.Enabled = false;
            gbxIds.Visible = false;
            btnConfirmarDestinos.Enabled = true;
            cbxDireccion.Enabled = false;
            cbxTrayecto.Enabled = false;
            cbxTrayecto.Items.Clear();
            cbxDireccion.Items.Clear();
            dgvEmbarqueLote.Rows.Clear();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            byte IdPaquete = Convert.ToByte((txtIdPaquete.Text));
            string destino = cbxHasta.SelectedItem.ToString();

            Paquete al = new Paquete
            {
                IdPaquete = IdPaquete
            };

            string paqueteEncontradoSerializado = APIalmacen.BuscarPaquete(JsonSerializer.Serialize(al), destino);

            if (!string.IsNullOrEmpty(paqueteEncontradoSerializado))
            {
                // Deserializa el paquete encontrado
                Paquete paqueteEncontrado = JsonSerializer.Deserialize<Paquete>(paqueteEncontradoSerializado);

                // Actualiza los datos del paquete original con los datos encontrados
                al = paqueteEncontrado;
                if (al.EstadoPaquete != "En Central")
                {
                    MessageBox.Show("Este Paquete no esta en Montevideo, o ya se armo un lote con el");
                }
                else
                {
                    // Ahora puedes agregar el paquete actualizado al DataGridView
                    n = dgvEmbarqueLote.Rows.Add();
                    dgvEmbarqueLote.Rows[n].Cells[0].Value = al.IdPaquete;
                    dgvEmbarqueLote.Rows[n].Cells[1].Value = al.EstadoPaquete;
                    dgvEmbarqueLote.Rows[n].Cells[2].Value = al.TipoPaquete;
                    dgvEmbarqueLote.Rows[n].Cells[3].Value = al.ciDestinatario;
                    dgvEmbarqueLote.Rows[n].Cells[4].Value = al.DestinoPaquete;
                    dgvEmbarqueLote.Rows[n].Cells[5].Value = al.ciudadDestinoPaquete;
                }
            }

            else
            {
                MessageBox.Show("Paquete no encontrado o no coincide con el destino del lote");
            }

            al = null;
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (n != -1) {
                try
                {
                    dgvEmbarqueLote.Rows.RemoveAt(n);
                }
                catch {
                    MessageBox.Show("Elija el elemento a eliminar haciendo click en el  y luego precionando este boton");
                }
            }
        }

        private void dgvEmbarqueLote_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            n = e.RowIndex;
            Console.WriteLine(n);
        }

        private void lblIdPaquete_Click(object sender, EventArgs e)
        {

        }

        private void btnGuardarLote_Click(object sender, EventArgs e)
        {
            //SACAR TODOS LOS DATOS DEL DGV

            //Guardar el Lote
            int guiaMadre = APIalmacen.GuardarLote();


            string plSer;

            foreach (DataGridViewRow row in dgvEmbarqueLote.Rows)
            {

                APIalmacen.PaqueLote paquelote = new APIalmacen.PaqueLote
                {
                    _GuiaMadre = guiaMadre,
                    _CodigoBarras = Convert.ToInt32(row.Cells[0].Value)
                };
                plSer = JsonSerializer.Serialize(paquelote);
                switch (APIalmacen.AgregarPaqueteALote(plSer))
                {
                    case 0:
                        break;
                    case 1:
                        MessageBox.Show("Por favor reinicie la aplicacion");
                        break;
                    case 2:
                        MessageBox.Show("Problema al intentar ingresar un paquete al lote, por favor consulte con un tecnico");
                        break;
                }
            }

            APIalmacen.LotTrayeLoc info = new APIalmacen.LotTrayeLoc
            {
                _direccionLocal = cbxDireccion.SelectedItem.ToString(),
                _GuiaMadre = guiaMadre,
                _nombreTrayecto = cbxTrayecto.SelectedItem.ToString()
            };
            string infoser = JsonSerializer.Serialize(info);
            //Guardar Corresponde
            switch (APIalmacen.InsertarCorresponde(infoser))
            
            {
                case 0:
                    break;
                case 1:
                    MessageBox.Show("Por favor reinicie la aplicacion");
                    break;
                case 2:
                    MessageBox.Show("Problema al intentar ingresar los trayectos, por favor consulte con un tecnico");
                    break;
            }
            

        }

        
        private void cbxTrayecto_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblHasta_Click(object sender, EventArgs e)
        {

        }

        private void cbxHasta_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxHasta.SelectedItem != null)
            {
                cbxDireccion.Enabled = true;
                cbxHasta.Enabled = false;
                List<string> direcciones = JsonSerializer.Deserialize<List<string>>(APIalmacen.BuscarDirecciones(cbxHasta.SelectedItem.ToString()));
                foreach (string direccion in direcciones)
                {
                    cbxDireccion.Items.Add(direccion);
                }
            }
        }

        private void cbxTrayecto_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void cbxDireccion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxDireccion.SelectedItem != null)
            {
                cbxTrayecto.Enabled = true; // Enable the next combo box
                cbxDireccion.Enabled = false;
                // Assuming you have a method similar to BuscarCiudades to get a list of cities for the selected trayecto
                List<string> direcciones = JsonSerializer.Deserialize<List<string>>(APIalmacen.BuscarTrayecto(cbxDireccion.SelectedItem.ToString()));

                // Fill the cbxHasta combo box with the retrieved cities
                foreach (string direccion in direcciones)
                {
                    cbxTrayecto.Items.Add(direccion);
                }
            }
        }
    }
}
