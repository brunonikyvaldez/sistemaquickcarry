﻿namespace SistemaQuickCarry
{
    partial class Inventario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCiDestinatario = new System.Windows.Forms.TextBox();
            this.txtDireccionDestino = new System.Windows.Forms.TextBox();
            this.lblTipoPaquete = new System.Windows.Forms.Label();
            this.lblCedula = new System.Windows.Forms.Label();
            this.lblDestino = new System.Windows.Forms.Label();
            this.lblCiudadDestino = new System.Windows.Forms.Label();
            this.cbxTipoPaquete = new System.Windows.Forms.ComboBox();
            this.cbxCiudadDestino = new System.Windows.Forms.ComboBox();
            this.txtAnioPerecedero = new System.Windows.Forms.TextBox();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.txtPesoPaquete = new System.Windows.Forms.TextBox();
            this.lblPesoPaquete = new System.Windows.Forms.Label();
            this.txtMesPerecedero = new System.Windows.Forms.TextBox();
            this.txtDiaPerecedero = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtCiDestinatario
            // 
            this.txtCiDestinatario.Location = new System.Drawing.Point(127, 114);
            this.txtCiDestinatario.Name = "txtCiDestinatario";
            this.txtCiDestinatario.Size = new System.Drawing.Size(134, 20);
            this.txtCiDestinatario.TabIndex = 2;
            // 
            // txtDireccionDestino
            // 
            this.txtDireccionDestino.Location = new System.Drawing.Point(124, 162);
            this.txtDireccionDestino.Name = "txtDireccionDestino";
            this.txtDireccionDestino.Size = new System.Drawing.Size(137, 20);
            this.txtDireccionDestino.TabIndex = 3;
            // 
            // lblTipoPaquete
            // 
            this.lblTipoPaquete.AutoSize = true;
            this.lblTipoPaquete.Location = new System.Drawing.Point(157, 9);
            this.lblTipoPaquete.Name = "lblTipoPaquete";
            this.lblTipoPaquete.Size = new System.Drawing.Size(71, 13);
            this.lblTipoPaquete.TabIndex = 5;
            this.lblTipoPaquete.Text = "Tipo Paquete";
            // 
            // lblCedula
            // 
            this.lblCedula.AutoSize = true;
            this.lblCedula.Location = new System.Drawing.Point(149, 98);
            this.lblCedula.Name = "lblCedula";
            this.lblCedula.Size = new System.Drawing.Size(97, 13);
            this.lblCedula.TabIndex = 6;
            this.lblCedula.Text = "Cedula destinatario";
            // 
            // lblDestino
            // 
            this.lblDestino.AutoSize = true;
            this.lblDestino.Location = new System.Drawing.Point(132, 146);
            this.lblDestino.Name = "lblDestino";
            this.lblDestino.Size = new System.Drawing.Size(126, 13);
            this.lblDestino.TabIndex = 7;
            this.lblDestino.Text = "Direccion de Destinatario";
            // 
            // lblCiudadDestino
            // 
            this.lblCiudadDestino.AutoSize = true;
            this.lblCiudadDestino.Location = new System.Drawing.Point(149, 195);
            this.lblCiudadDestino.Name = "lblCiudadDestino";
            this.lblCiudadDestino.Size = new System.Drawing.Size(79, 13);
            this.lblCiudadDestino.TabIndex = 8;
            this.lblCiudadDestino.Text = "Ciudad Destino";
            // 
            // cbxTipoPaquete
            // 
            this.cbxTipoPaquete.FormattingEnabled = true;
            this.cbxTipoPaquete.Items.AddRange(new object[] {
            "Fragil",
            "Comun",
            "Perecedero"});
            this.cbxTipoPaquete.Location = new System.Drawing.Point(124, 25);
            this.cbxTipoPaquete.Name = "cbxTipoPaquete";
            this.cbxTipoPaquete.Size = new System.Drawing.Size(134, 21);
            this.cbxTipoPaquete.TabIndex = 9;
            this.cbxTipoPaquete.Text = "<Tipo Paquete>";
            this.cbxTipoPaquete.SelectedIndexChanged += new System.EventHandler(this.cbxTipoPaquete_SelectedIndexChanged);
            // 
            // cbxCiudadDestino
            // 
            this.cbxCiudadDestino.FormattingEnabled = true;
            this.cbxCiudadDestino.Items.AddRange(new object[] {
            "Artigas, Artigas",
            "Canelones, Canelones",
            "Melo, Cerro Largo",
            "Colonia del Sacramento, Colonia",
            "Durazno, Durazno",
            "Trinidad, Flores",
            "Florida, Florida",
            "Minas, Lavalleja",
            "Maldonado, Maldonado",
            "Paysandu, Paysandu",
            "Fray Bentos, Rio Negro",
            "Rivera, Rivera",
            "Rocha, Rocha",
            "Salto, Salto",
            "San Jose de Mayo, San Jose",
            "Mercedes, Soriano",
            "Tacuarembo, Tacuarembo",
            "Treinta y tres, Treinta y tres"});
            this.cbxCiudadDestino.Location = new System.Drawing.Point(124, 221);
            this.cbxCiudadDestino.Name = "cbxCiudadDestino";
            this.cbxCiudadDestino.Size = new System.Drawing.Size(134, 21);
            this.cbxCiudadDestino.TabIndex = 11;
            this.cbxCiudadDestino.Text = "<Ciudad de Destino>";
            // 
            // txtAnioPerecedero
            // 
            this.txtAnioPerecedero.Location = new System.Drawing.Point(137, 69);
            this.txtAnioPerecedero.Name = "txtAnioPerecedero";
            this.txtAnioPerecedero.Size = new System.Drawing.Size(28, 20);
            this.txtAnioPerecedero.TabIndex = 12;
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(108, 287);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(167, 23);
            this.btnGuardar.TabIndex = 13;
            this.btnGuardar.Text = "Guardar paquete";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // txtPesoPaquete
            // 
            this.txtPesoPaquete.Location = new System.Drawing.Point(124, 261);
            this.txtPesoPaquete.Name = "txtPesoPaquete";
            this.txtPesoPaquete.Size = new System.Drawing.Size(137, 20);
            this.txtPesoPaquete.TabIndex = 14;
            // 
            // lblPesoPaquete
            // 
            this.lblPesoPaquete.AutoSize = true;
            this.lblPesoPaquete.Location = new System.Drawing.Point(134, 245);
            this.lblPesoPaquete.Name = "lblPesoPaquete";
            this.lblPesoPaquete.Size = new System.Drawing.Size(111, 13);
            this.lblPesoPaquete.TabIndex = 15;
            this.lblPesoPaquete.Text = "Peso Del Paquete(kg)";
            // 
            // txtMesPerecedero
            // 
            this.txtMesPerecedero.Location = new System.Drawing.Point(185, 69);
            this.txtMesPerecedero.Name = "txtMesPerecedero";
            this.txtMesPerecedero.Size = new System.Drawing.Size(28, 20);
            this.txtMesPerecedero.TabIndex = 16;
            // 
            // txtDiaPerecedero
            // 
            this.txtDiaPerecedero.Location = new System.Drawing.Point(230, 69);
            this.txtDiaPerecedero.Name = "txtDiaPerecedero";
            this.txtDiaPerecedero.Size = new System.Drawing.Size(28, 20);
            this.txtDiaPerecedero.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(140, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "año";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(187, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "mes";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(227, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(21, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "dia";
            // 
            // Inventario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(378, 363);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtDiaPerecedero);
            this.Controls.Add(this.txtMesPerecedero);
            this.Controls.Add(this.lblPesoPaquete);
            this.Controls.Add(this.txtPesoPaquete);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.txtAnioPerecedero);
            this.Controls.Add(this.cbxCiudadDestino);
            this.Controls.Add(this.cbxTipoPaquete);
            this.Controls.Add(this.lblCiudadDestino);
            this.Controls.Add(this.lblDestino);
            this.Controls.Add(this.lblCedula);
            this.Controls.Add(this.lblTipoPaquete);
            this.Controls.Add(this.txtDireccionDestino);
            this.Controls.Add(this.txtCiDestinatario);
            this.Name = "Inventario";
            this.Text = "Inventario";
            this.Load += new System.EventHandler(this.Inventario_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtCiDestinatario;
        private System.Windows.Forms.TextBox txtDireccionDestino;
        private System.Windows.Forms.Label lblTipoPaquete;
        private System.Windows.Forms.Label lblCedula;
        private System.Windows.Forms.Label lblDestino;
        private System.Windows.Forms.Label lblCiudadDestino;
        private System.Windows.Forms.ComboBox cbxTipoPaquete;
        private System.Windows.Forms.ComboBox cbxCiudadDestino;
        private System.Windows.Forms.TextBox txtAnioPerecedero;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.TextBox txtPesoPaquete;
        private System.Windows.Forms.Label lblPesoPaquete;
        private System.Windows.Forms.TextBox txtMesPerecedero;
        private System.Windows.Forms.TextBox txtDiaPerecedero;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}