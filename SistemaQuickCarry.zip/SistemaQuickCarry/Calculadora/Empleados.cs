﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;

namespace SistemaQuickCarry
{
    class Empleados
    {

        protected Int32 _ci;
        protected string _rol;
        protected string _primerNombre;
        protected string _segundoNombre;
        protected string _primerApellido;
        protected string _segundoApellido;
        protected string _usuario;
        protected byte _idUsuario;
        protected ADODB.Connection _conexion;
        protected string _contrasenia;
        public string contrasenia
        {
            set { _contrasenia = value; }
            get { return (_contrasenia); }
        }
        public byte idUsuario
        {
            set { _idUsuario = value; }
            get { return (_idUsuario); }
        }
        public Int32 ci
        {
            set { _ci = value; }
            get { return (_ci); }
        }
        public string primerNombre
        {
            set { _primerNombre = value; }
            get { return (_primerNombre); }
        }
        public string segundoNombre
        {
            set { _segundoNombre = value; }
            get { return (_segundoNombre); }
        }
        public string primerApellido
        {
            set { _primerApellido = value; }
            get { return (_primerApellido); }
        }
        public string segundoApellido   
        {
            set { _segundoApellido = value; }
            get { return (_segundoApellido); }
        }
        public ADODB.Connection conexion
        {
            set { _conexion = value; }
            get { return (_conexion); }
        }
        public string usuario
        {
            set { _usuario = value; }
            get { return (_usuario); }
        }
        public string rol
        {
            set { _rol = value; }
            get { return (_rol); }
        }
        public Empleados()
        {
            _ci = 0; // 7-9 digitos
            _primerNombre = "";
            _segundoNombre = "";
            _primerApellido = "";
            _segundoApellido = ""; 
            _usuario = ""; // no mas de 15 caracteres
            _conexion = new ADODB.Connection();
        }




        public byte Guardar()
        {
            string sql;
            object filasAfectadas;
            byte resultado = 0;

            if (_conexion.State == 0)
            {
                resultado = 1; // conexión cerrada
            }

            else
            {
                DateTime hoy = DateTime.Now;

                sql = $"INSERT INTO Empleado (NroDocumento, Usuario, PrimerNombre, SegundoNombre, PrimerApellido, SegundoApellido, FinalLicencia) " +
                      $"VALUES ({_ci}, '{_usuario}', '{_primerNombre}', '{_segundoNombre}', '{_primerApellido}', '{_segundoApellido}','{hoy.Year}-{hoy.Month}-{hoy.Day}')";

                try
                {
                    _conexion.BeginTrans(); // Iniciar una transacción

                    _conexion.Execute(sql, out filasAfectadas);

                    // Obtén el ID del nuevo usuario 
                    sql = "SELECT LAST_INSERT_ID() AS ID";
                    ADODB.Recordset rs = _conexion.Execute(sql, out filasAfectadas);

                    if (rs.RecordCount > 0)
                    {
                        _idUsuario = Convert.ToByte(rs.Fields["ID"].Value);
                    }

                    // Agregar a la tabla de Almacenero
                    if (_rol == "Almacenero" || _rol == "Administrador")
                    {
                        int esAdmin = (_rol == "Administrador") ? 1 : 0;

                        sql = $"INSERT INTO Almacenero (IDEmpleado, EsAdmin) VALUES ({_idUsuario}, {esAdmin})";
                        _conexion.Execute(sql, out filasAfectadas);

                        // Crear usuario con permisos para Almacenero
                        sql = $"CREATE USER {_usuario} identified by '{contrasenia}'";
                        _conexion.Execute(sql, out filasAfectadas);

                        // Asignar permisos para Almacenero
                        sql = $"GRANT INSERT, UPDATE, DELETE, SELECT ON quickcarry.* TO '{_usuario}'";
                        _conexion.Execute(sql, out filasAfectadas);

                        if (_rol == "Administrador")
                        {
                            // Si es administrador, otorgar GRANT OPTION
                            sql = $"GRANT GRANT OPTION ON quickcarry.* TO '{_usuario}'";
                            _conexion.Execute(sql, out filasAfectadas);
                        }
                    }
                    else if (_rol == "Camionero")
                    {
                        // Agregar a la tabla de ConductorCamion
                        sql = $"INSERT INTO ConductorCamion (IDEmpleado) VALUES ({_idUsuario})";
                        _conexion.Execute(sql, out filasAfectadas);

                        // Crear usuario con permisos para Camionero
                        sql = $"CREATE USER '{_usuario}'identified by '{contrasenia}'";
                        _conexion.Execute(sql, out filasAfectadas);

                        // Asignar permisos para Camionero
                        sql = $"GRANT INSERT, UPDATE, DELETE, SELECT ON quickcarry.* TO '{_usuario}'";
                        _conexion.Execute(sql, out filasAfectadas);
                    }
                    else if (_rol == "Conductor")
                    {
                        // Agregar a la tabla de ConductorCamioneta
                        sql = $"INSERT INTO ConductorCamioneta (IDEmpleado) VALUES ('{_idUsuario}')";
                        _conexion.Execute(sql, out filasAfectadas);

                        // Crear usuario con permisos para Conductor
                        sql = $"CREATE USER '{_usuario}' identified by '{contrasenia}'";
                        _conexion.Execute(sql, out filasAfectadas);

                        // Asignar permisos para Conductor
                        sql = $"GRANT INSERT, UPDATE, DELETE, SELECT ON quickcarry.* TO '{_usuario}'";
                        _conexion.Execute(sql, out filasAfectadas);
                    }

                    _conexion.CommitTrans(); // Confirmar la transacción
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex);
                    _conexion.RollbackTrans(); // Revertir la transacción en caso de error
                    resultado = 4; // error al insertar en la tabla
                }

            }

            return resultado;
        }



        public byte Eliminar()
        {
            byte resultado = 0;
            string sql;
            object filasAfectadas;

            if (_conexion.State == 0)
            {
                resultado = 1; // conexión cerrada
            }
            else
            {
                sql = $"DELETE FROM Empleado WHERE IDEmpleado = {_idUsuario}";

                try
                {
                    _conexion.BeginTrans(); // Iniciar una transacción

                    _conexion.Execute(sql, out filasAfectadas);

                    // También puedes definir consultas adicionales para eliminar registros relacionados en otras tablas si es necesario

                    _conexion.CommitTrans(); // Confirmar la transacción
                }
                catch
                {
                    _conexion.RollbackTrans(); // Revertir la transacción en caso de error
                    resultado = 2; // error al eliminar usuario
                }
            }

            return resultado;
        }
    }
}
