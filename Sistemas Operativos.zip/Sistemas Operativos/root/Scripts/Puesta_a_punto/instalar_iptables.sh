#!/bin/bash
yum -y install iptables-services iptables-devel iptables-utils
